package yi.programiranje.calculator.gui;

public enum CalculatorUIMessage {
	SUCESS, INFO, ERROR
}
