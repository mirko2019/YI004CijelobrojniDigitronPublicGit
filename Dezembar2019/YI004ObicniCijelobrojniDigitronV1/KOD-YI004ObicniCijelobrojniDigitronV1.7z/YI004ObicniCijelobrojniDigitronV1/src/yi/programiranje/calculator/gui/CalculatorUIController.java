/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yi.programiranje.calculator.gui;

import java.math.BigInteger;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;

public class CalculatorUIController implements Initializable {

    private BigInteger temp = new BigInteger("0"), sum = new BigInteger("0");
    private boolean isOperatorPressed;
    private String operatorPressed = "";
    private boolean onError = false; 
    
    @FXML TextField outputTF;       
    @FXML TextArea outputTA; 
    
    @FXML TextField viewND; 
    @FXML TextField viewEW;
    @FXML TextField viewCP; 
    
    @FXML Pane infoPanel; 
    @FXML Label infoLabel; 
    
    private void message(String message, CalculatorUIMessage category) {
    	switch(category) {
    		case INFO: 
    			infoPanel.getStylesheets().clear(); 
    			infoPanel.getStylesheets().add("/yi/programiranje/calculator/gui/CalculatorUIInfoPanelMessageStyle.css");
    			break;
       		case SUCESS: 
    			infoPanel.getStylesheets().clear(); 
    			infoPanel.getStylesheets().add("/yi/programiranje/calculator/gui/CalculatorUIInfoPanelSuccessStyle.css");
    			break;
       		case ERROR: 
       			infoPanel.getStylesheets().clear(); 
    			infoPanel.getStylesheets().add("/yi/programiranje/calculator/gui/CalculatorUIInfoPanelErrorStyle.css");
       			break;
    	}
    	infoPanel.applyCss();
    	infoLabel.applyCss();
    	infoLabel.setText(message);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    	message("Спремно.", CalculatorUIMessage.INFO);
    	outputTF.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
            	if(newValue.length()>10000) {
            		outputTF.setText(oldValue);
            		return; 
            	}
            	
            	if (!newValue.matches("\\d*")) {
                    outputTF.setText(oldValue);
                    return;
                }
                
                if(outputTF.getText().length()==0) {
                    viewND.setText("");
                    viewEW.setText("");
                    outputTA.setText("");
                    return; 
                }
                NumberFormat formatter = new DecimalFormat("0.######E0", DecimalFormatSymbols.getInstance(Locale.ROOT));
                String str = formatter.format(new BigInteger(outputTF.getText())); 
                
                viewND.setText(Integer.toString(outputTF.getText().length()));
                viewEW.setText(str);
                outputTA.setText(new BigInteger(outputTF.getText()).toString());
                
                if(outputTF.getLength()>1 && outputTF.getText().startsWith("0")) {
                	Platform.runLater(()->{
                		outputTF.setText(new BigInteger(outputTF.getText()).toString());
                	}); 
                }
            }
        });
    }    
    
    @FXML
    private void onNumberClick(ActionEvent event) {
        if(event.getSource() instanceof Button) {
            Button btn = (Button)event.getSource();                                               
            if(isOperatorPressed) {
                outputTF.setText(btn.getText().trim());                
            } else {
                outputTF.setText(outputTF.getText().trim() + btn.getText().trim());
            }
            isOperatorPressed = false;
        }
    }
    
    @FXML
    private void onOperatorClick(ActionEvent event) {
        if(event.getSource() instanceof Button) {
            Button btn = (Button)event.getSource();            
            if (!outputTF.getText().isEmpty()) {
            	String oText = outputTF.getText(); 
            	if(oText.isEmpty()) oText = "0";
                temp = new BigInteger(oText);
                if(!isOperatorPressed)
	                switch (operatorPressed) {
	                	case "MOD": 
	                		if(temp.equals(new BigInteger("0"))) {
	                			message("Цијелобројни модуо са нулом није могућ.", CalculatorUIMessage.ERROR);
	                			onError = true; 
	                			break;
	                		}
	                		temp = sum.mod(temp);
	                        sum = temp; 
	                        break;
	                    case ":":
	                    	if(temp.equals(new BigInteger("0"))) {
	                			message("Цијелобројно дијељење са нулом није могућe.", CalculatorUIMessage.ERROR);
	                			onError = true; 
	                			break;
	                		}
	                        temp = sum.divide(temp);
	                        sum = temp; 
	                        break;
	                    case "*":
	                    	 temp = sum.multiply(temp);
	                    	 if(temp.toString().length()>10000) {
	                			message("Прекорачење од 10000 цифара није дозвољено.", CalculatorUIMessage.ERROR);
	                			onError = true; 
	                			break;
	                		 }
	                         sum = temp; 
	                        break;
	                    case "+": 
	                   	 	temp = sum.add(temp);
	                   	 	if(temp.toString().length()>10000) {
	                			message("Прекорачење од 10000 цифара није дозвољено.", CalculatorUIMessage.ERROR);
	                			onError = true; 
	                			break;
	                		}
	                   	 	sum = temp;
	                   	 	break;
	                    case "-":
	                		if(temp.compareTo(sum)>0) {
	                			message("Рад са негативним бројевима није подржан.", CalculatorUIMessage.ERROR);
	                			onError=true; 
	                			break;
	                		}
	                   	 	temp = sum.subtract(temp);
	                   	 	sum = temp;
	                        break;
	                    default:
	                        sum = temp;
	                }
                isOperatorPressed = true;
            }                     
            
            outputTF.setText(String.valueOf(sum));
            if (btn.getText().equals("=")) {   
            	NumberFormat formatter = new DecimalFormat("0.######E0", DecimalFormatSymbols.getInstance(Locale.ROOT));
                String suma = formatter.format(new BigInteger(outputTF.getText())); 
                operatorPressed = "";
                if(!onError) message("Резултат "+suma+".", CalculatorUIMessage.SUCESS);
                onError = false;
            } else {   
            	if(onError) {
            		 operatorPressed = "";
            		 onError = false;
            		 return; 
            	}
                operatorPressed = btn.getText().trim();
                NumberFormat formatter = new DecimalFormat("0.######E0", DecimalFormatSymbols.getInstance(Locale.ROOT));
                String suma = formatter.format(sum); 
                switch(operatorPressed) {
                	case "+": 
                		message("Сабирање. Први сабирак је "+suma+", а други се уноси.", CalculatorUIMessage.INFO);
                		break;
                	case "-": 
                		message("Одузимање. Умањеник је "+suma+", а умањилац се уноси.", CalculatorUIMessage.INFO);
                		break;
                	case "*": 
                		message("Множење. Први чинилац је "+suma+", а други се уноси.", CalculatorUIMessage.INFO);
                		break; 
                	case ":": 
                		message("Цијелобројно дијељење. Дијељеник је "+suma+", а дијелилац се уноси.", CalculatorUIMessage.INFO);
                		break;
                	case "MOD": 
                		message("Остатак цијелобројног дијељења (модуо). Дијељеник је "+suma+", а дијелилац се уноси.", CalculatorUIMessage.INFO);
                		break;
                }
            } 
        }
    }        
    
    @FXML
    private void onDELClick(ActionEvent event) {
        if(outputTF.getText().length() > 0) {
            outputTF.setText(outputTF.getText(0, outputTF.getText().length() - 1));
        }        
    }
    
    @FXML
    private void onCEClick(ActionEvent event) {
        outputTF.setText("");
        temp = new BigInteger("0");
        sum = new BigInteger("0");
        isOperatorPressed = false;
        operatorPressed = "";
        onError=false; 
        message("Спремно.", CalculatorUIMessage.INFO);
    }
    
    @FXML
    private void onCloseClick(ActionEvent event) {
    	Platform.exit();
    }
    
    @FXML
    private void onTFClick(MouseEvent event) {
    	try {
    		viewCP.setText(Integer.toString(outputTF.getLength()-outputTF.getCaretPosition()));
    		isOperatorPressed = false;
    	}catch(Exception ex) {
    		viewCP.setText("0");
    	}
    }
    
    @FXML
    private void onTAClick(MouseEvent event) {
    	try {
    		viewCP.setText(Integer.toString(outputTA.getLength()-outputTA.getCaretPosition()));
    	}catch(Exception ex) {
    		viewCP.setText("0");
    	}
    }
    
    @FXML
    private void onTFPress(KeyEvent event) {
    	try {
    		viewCP.setText(Integer.toString(outputTF.getLength()-outputTF.getCaretPosition()));
    		isOperatorPressed = false;
    	}catch(Exception ex) {
    		viewCP.setText("0");
    	}
    }
}
